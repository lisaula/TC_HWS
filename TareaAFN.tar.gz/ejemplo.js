export default class Ejemplo {
	constructor(texto){
		this.txt = texto
	}

	addProperty(algo){
		this.nuevo = algo;
	}
}